import pandas as pd
import os
from praatio import textgrid

class tgdata:
    def __init__(self, textgrid_file_path:str):
        textgrid_file = textgrid.openTextgrid(textgrid_file_path, includeEmptyIntervals=True)
        self.filename = os.path.basename(textgrid_file_path)
        self.nsyll = len(textgrid_file._tierDict['Nuclei'].entries)
        nsounding   = 0
        speakingtot = 0
        silenttot = 0
        for interval in textgrid_file._tierDict['Phrases'].entries:
            if interval.label != '':
                nsounding   += 1
                ts = interval.start
                te = interval.end
                speakingtot += te - ts
            else:
                ts = interval.start
                te = interval.end
                silenttot += te - ts

        # silenttotから最初と最後の無言部分を抜く
        if textgrid_file._tierDict['Phrases'].entries[-1] == '':
            silenttot -=  (textgrid_file._tierDict['Phrases'].entries[-1].end - textgrid_file._tierDict['Phrases'].entries[-1].start)
        
        if textgrid_file._tierDict['Phrases'].entries[0] == '':
            silenttot -=  (textgrid_file._tierDict['Phrases'].entries[0].end - textgrid_file._tierDict['Phrases'].entries[0].start)

        self.silenttot = silenttot

        self.speakingtot = speakingtot
        # ASD(speakingtime/nsyll)        
        self.asd = self.speakingtot / self.nsyll
        self.nsounding = nsounding
        self.npause = nsounding - 1
        self.durs = textgrid_file.maxTimestamp
        acum = 0.0
        for start, end, label in textgrid_file._tierDict['Phrases'].entries:
            if label != '':
                acum += end - start
        self.phonationtime = acum
        nrFP = 0
        ts = 0
        te = 0
        tFP = 0.0
        nrRP = 0
        tRP = 0.0
        for start, end, label in textgrid_file._tierDict['DFauto (English)'].entries:
            if label == 'fp':
                nrFP += 1
                ts = start
                te = end
                tFP += (te - ts)
            elif label == 'rp':
                nrRP += 1
                ts = start
                te = end
                tRP += (te - ts)
        self.nrFP = nrFP
        self.tFP = tFP
        self.nrRP = nrRP
        self.tRP = tRP
        # speechrate(nsyll/dur)
        self.speechrate = self.nsyll / self.durs
        #SR = voicedcount / dur * 60；Repair(rp)は含むが、filled pause(fp)は含まない
        self.SR = (self.nsyll - self.nrFP) / self.durs * 60
        #SRP = voicedcount / dur * 60；Repair(rp)もfilled pause(fp)も含まない
        self.SRP = (self.nsyll - self.nrFP - self.nrRP) / self.durs * 60

        # articulation_rate(nsyll/phonationtime)
        self.articulation_rate = self.nsyll / self.phonationtime
        # AR = voicedcount / speakingtot * 60；Repair(rp)は含むが、filled pause(fp)は含まない
        self.AR = (self.nsyll - self.nrFP) / self.speakingtot * 60
        # ARP = voicedcount / speakingtot * 60;  Repair(rp)もfilled pause(fp)も含まない
        self.ARP = (self.nsyll - self.nrFP - self.nrRP) / self.speakingtot * 60
        # Mean Length of Runs ポーズとポーズの間で発話された音節数の平均。
        # 除外されない全てのPhrase番号のところの音節数の平均の値
        # ３番目のtierに、rpか、fpがある時には音節数に加えない。
        try:
            self.MLoR = (self.nsyll - self.nrFP - self.nrRP) / (self.nsounding  - self.nrFP - self.nrRP)
        except ZeroDivisionError:
            self.MLoR = 0
        # PhonRat= speakingtot / dur * 100；発話率（％表示）
        self.PhonRat = self.speakingtot / self.durs

        # SPauseFreq ; １分間に産出されたSilent Pauseの数; 
        # ２番目のtierの番号が入っていない境界部分の数 / dur * 60；発話開始前と開始後の空白を除く。
        self.SPauseFreq = (self.npause) / self.durs * 60

        # SPauseDur =  Silent Pauseのの長さの平均（秒）; 
        # サイレントポーズの長さの平均；２番目のtierの番号が入っていない
        # 部分の長さの平均；発話開始前と開始後の空白を除く。
        try:
            self.SPauseDur = self.silenttot / self.npause
        except ZeroDivisionError:
            self.SPauseDur = 0

        # FPauseFreq ;  １分間に産出されたFilled Pauseの数
        self.FPauseFreq = self.nrFP / self.durs * 60

        # FPauseDur；１分間に産出されたFilled Pauseの長さの合計（秒）
        self.FPauseDur = self.tFP / self.durs * 60

        # RpFreq ;  １分間に産出されたRepairの音節数
        self.RpFreq = self.nrRP / self.durs * 60

        # RpDur；Repairの長さの合計（秒）
        self.RpDur = self.tRP / self.durs * 60

# tg = textgrid.openTextgrid('test.TextGrid', includeEmptyIntervals=True)


tgd = tgdata('Sample filled pause and long I.auto.TextGrid')


df = pd.DataFrame([tgd.__dict__])
df.to_csv("output.csv", index=True)
df.to_excel("output.xlsx", index = True)
print('finished')