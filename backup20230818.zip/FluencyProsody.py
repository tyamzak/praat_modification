import pandas as pd
import os
import math
from praatio import textgrid


class tgdata:
    def __init__(self, textgrid_file_path: str):
        textgrid_file = textgrid.openTextgrid(
            textgrid_file_path, includeEmptyIntervals=True
        )
        self.filename = os.path.basename(textgrid_file_path)
        self.ID = self.filename[0:3]
        self.RECN = self.filename[3:6]
        self.Date = (
            self.filename[6:8] + "-" + self.filename[8:10] + "-" + self.filename[10:12]
        )
        # ,'ID','RECN','Date'

        self.nsyll = len(
            [
                x
                for x in textgrid_file._tierDict["DFauto (English)"].entries
                if x.label == "v"
            ]
        )
        # self.nsyll = len(textgrid_file._tierDict['Nuclei'].entries)
        nsounding = 0
        npause_ps = 0
        npause_psb = 0
        speakingtot = 0
        silenttot_ps = 0
        silenttot_psb = 0
        for interval in textgrid_file._tierDict["Phrases"].entries:
            if interval.label == "pr":
                nsounding += 1
                ts = interval.start
                te = interval.end
                speakingtot += te - ts
            elif interval.label == "ps":
                npause_ps += 1
                ts = interval.start
                te = interval.end
                silenttot_ps += te - ts
            elif interval.label == "psb":
                npause_psb += 1
                ts = interval.start
                te = interval.end
                silenttot_psb += te - ts
            else:
                # print('想定外のラベル: Phrases   ' + interval.label)
                pass

        self.silenttot = silenttot_ps + silenttot_psb
        self.silenttot_ps = silenttot_ps
        self.silenttot_psb = silenttot_psb

        self.speakingtot = speakingtot

        self.asd = self.speakingtot / self.nsyll
        self.nsounding = nsounding
        self.npause = npause_ps + npause_psb
        self.npause_ps = npause_ps
        self.npause_psb = npause_psb

        nrFP = 0
        ts = 0
        te = 0
        tFP = 0.0
        nrRP = 0
        tRP = 0.0
        # 個数はTier3からとる
        for start, end, label in textgrid_file._tierDict["DFauto (English)"].entries:
            if label == "fp":
                nrFP += 1

            elif label == "rp":
                nrRP += 1

        # 時間はTier2からとる
        for start, end, label in textgrid_file._tierDict["Phrases"].entries:
            if label == "fp":
                ts = start
                te = end
                tFP += te - ts
            elif label == "rp":
                ts = start
                te = end
                tRP += te - ts
        self.nrFP = nrFP
        self.tFP = tFP
        self.nrRP = nrRP
        self.tRP = tRP
        # speechrate(nsyll/dur)
        self.durs = (
            self.tFP
            + self.tRP
            + self.speakingtot
            + self.silenttot_ps
            + self.silenttot_psb
        )
        # self.speechrate = self.nsyll / self.durs
        # SR = voicedcount / dur * 60；Repair(rp)は含むが、filled pause(fp)は含まない
        self.SR = round((self.nsyll + self.nrRP) / self.durs * 60, 2)
        # SRP = voicedcount / dur * 60；Repair(rp)もfilled pause(fp)も含まない
        self.SRP = round((self.nsyll) / self.durs * 60, 2)

        # articulation_rate(nsyll/phonationtime)
        # self.articulation_rate = self.nsyll / self.phonationtime

        # AR = voicedcount / speakingtot * 60；Repair(rp)は含むが、filled pause(fp)は含まない
        self.AR = round(
            (self.nsyll + self.nrRP) / (self.speakingtot + self.tRP) * 60, 2
        )

        # ARP = voicedcount / speakingtot * 60;  Repair(rp)もfilled pause(fp)も含まない
        self.ARP = round((self.nsyll) / self.speakingtot * 60, 2)

        # Mean Length of Runs ポーズとポーズの間で発話された音節数の平均。
        # 除外されない全てのPhrase番号のところの音節数の平均の値
        # ３番目のtierに、rpか、fpがある時には音節数に加えない。
        try:
            self.MLoR = round((self.nsyll) / (self.nsounding), 2)
        except ZeroDivisionError:
            self.MLoR = 0

        # PhonRat= speakingtot / dur * 100；発話率（％表示）
        self.PhonRat = format((self.speakingtot + self.tRP) / self.durs * 100, ".2f")

        # SPauseFreq ; １分間に産出されたSilent Pauseの数;
        # ２番目のtierの番号が入っていない境界部分の数 / dur * 60；発話開始前と開始後の空白を除く。
        self.SPauseFreq = round((self.npause) / self.durs * 60, 2)

        # SPauseDur =  Silent Pauseのの長さの平均（秒）;
        # サイレントポーズの長さの平均；２番目のtierの番号が入っていない
        # 部分の長さの平均；発話開始前と開始後の空白を除く。
        try:
            self.SPauseDur = round(self.silenttot / self.npause, 2)
        except ZeroDivisionError:
            self.SPauseDur = 0

        # FPauseFreq ;  １分間に産出されたFilled Pauseの数
        self.FPauseFreq = round(self.nrFP / self.durs * 60, 2)

        # FPauseDur；１分間に産出されたFilled Pauseの長さの合計（秒）
        self.FPauseDur = round(self.tFP / self.durs * 60, 2)

        # RpFreq ;  １分間に産出されたRepairの音節数
        self.RpFreq = round(self.nrRP / self.durs * 60, 2)

        # RpDur；Repairの長さの合計（秒）
        self.RpDur = round(self.tRP / self.durs * 60, 2)

        # SBPauseFreq ; ２番目のtierに、「"psb"がはいっている境界部分」の数 / dur * 60
        self.SBPauseFreq = round(self.npause_psb / self.durs * 60, 2)

        # SBPauseDur ; ２番目のtierに、「"psb"がはいっている境界部分」の長さの平均；
        if self.npause_psb == 0:
            self.SBPauseDur = 0
        else:
            self.SBPauseDur = round(self.silenttot_psb / self.npause_psb, 2)

        # SWPauseFreq ; ２番目のtierに、「"ps"がはいっている境界部分」の数 / dur * 60；
        self.SWPauseFreq = round(self.npause_ps / self.durs * 60, 2)
        try:
            # SWPauseDur ; 2番目のtierに、「"ps"がはいっている境界部分」の長さの平均；
            self.SWPauseDur = round(self.silenttot_ps / self.npause_ps, 2)
        except ZeroDivisionError:
            self.SWPauseDur = 0

        textgrid_file = self.vl_jp_modification(textgrid_file)

        self.duration(textgrid_file)

    def vl_jp_modification(self, tg: textgrid) -> textgrid:
        """
        fluencyの処理の後に行う
        Tier5 jpがある範囲において、Tier3のv:labelをjp:labelに変更する
        長さが500ms以上の母音であれば、Tier3の”v”を”vl”に書き換える
        Args:
            tg (textgrid): _description_
        """

        # Tier5に"jp"というラベルのついたintervalを検索する
        jp_intervals = []
        if "Japanese" in tg._tierDict.keys():
            for interval in tg._tierDict["Japanese"].entries:
                if interval.label == "jp":
                    jp_intervals.append(interval)

        # Tier3に"v"というラベルのついたintervalのラベルを変更する
        tier3 = tg._tierDict["DFauto (English)"]
        for interval in tier3.entries:
            for jp_interval in jp_intervals:
                if (
                    interval.start >= jp_interval.start
                    and interval.end <= jp_interval.end
                ):
                    if interval.label == "v":
                        tier3.insertEntry(
                            (interval.start, interval.end, "jp"),
                            collisionMode="replace",
                            collisionReportingMode="silence",
                        )

            if interval.label == "v":
                if (interval.end - interval.start) >= 0.5:
                    tier3.insertEntry(
                        (interval.start, interval.end, "vl"),
                        collisionMode="replace",
                        collisionReportingMode="silence",
                    )

        return tg

    def duration(self, tg):
        # print('duration')
        # tg._tierDict['Phrases'].entries
        # pr_startからpr_endまでの間で発生したvを全て対象にする
        # tg._tierDict['DFauto (English)'].entries

        #############################################################################
        # nPVIの計算
        # 隣り合う母音(Pair)の長さの差（絶対値）を、２つの母音の長さの平均で割ったものを合計し、
        # 母音の数―１（すなわちペアの数）で割ったものに１００をかけたもの。

        total_v_entries = []
        max_and_min_in_prs = []
        max_and_min_in_PitRangeAv = []
        max_and_min_in_IntRangeAv = []
        undefined = 0
        for ph_entry in tg._tierDict["Phrases"].entries:
            v_entries = []

            # Tier2 Phrases で　PRの開始と終了を取得する pr_start, pr_end,
            if ph_entry.label == "pr":
                pr_start = ph_entry.start
                pr_end = ph_entry.end

                for i, v in enumerate(tg._tierDict["DFauto (English)"].entries):
                    dfeng_entry = v

                    # prの範囲内だった場合で、labelがvかvfの場合
                    if (
                        pr_start <= dfeng_entry.start
                        and dfeng_entry.end <= pr_end
                        and dfeng_entry.label in ["v", "vf"]
                    ):
                        # vだった場合に追加する。

                        # Pitch用の計算###########################
                        f0 = tg._tierDict["Pitch"].entries[i].label

                        # f0が--undefined--だった場合、一つ前のPitch_PPD_validを無効にする
                        if f0 == "--undefined--" and i != 0:
                            Mel = "--undefined--"
                            v_entries[-1]["Pitch_PPD_valid"] = False
                            undefined += 1
                        else:
                            Mel = 2595 * math.log10(1 + float(f0) / 700)

                        # Intensity用の計算########################
                        dB = tg._tierDict["Intensity"].entries[i].label
                        ########################################
                        dict_v_entry = {
                            "start": dfeng_entry.start,
                            "end": dfeng_entry.end,
                            "duration": dfeng_entry.end - dfeng_entry.start,
                            "duration_valid": True,
                            "is_DurRangeAv_target": True,
                            "Tier3Index": i,
                            "f0": f0,
                            "Mel": Mel,
                            "Pitch_PPD_valid": True,
                            "Pitch_other_valid": True,
                            "dB": float(dB),
                            "Intensity_PID_valid": True,
                            "Intensity_other_valid": True,
                        }

                        v_entries.append(dict_v_entry)

                    # 空白は無視する
                    elif dfeng_entry.label == "":
                        pass

                    else:
                        # v_entriesが0ではなく、かつvではなかった場合、一つ前のvを無効にする
                        # PPD_validとPitch_other_validも無効にする
                        if v_entries:
                            v_entries[-1]["duration_valid"] = False
                            v_entries[-1]["is_DurRangeAv_target"] = False
                            v_entries[-1]["Pitch_PPD_valid"] = False
                            # v_entries[-1]["Pitch_other_valid"] = False
                            v_entries[-1]["Intensity_PID_valid"] = False
                            # v_entries[-1]["Intensity_other_valid"] = False

            # 絶対値と平均を取得していく
            for i in range(0, len(v_entries)):
                # ”pr”範囲の最後のを含むペアは、計算に入れない
                if i == len(v_entries) - 1:
                    # 最後を開始とする範囲と
                    # v_entries[i]["abs"] = 0
                    # v_entries[i]["avg"] = 0

                    # 最後の一つ前から最後までの範囲を無効にする
                    v_entries[i - 1]["duration_valid"] = False
                    v_entries[i - 1]["Pitch_PPD_valid"] = False
                    v_entries[i - 1]["Intensity_PID_valid"] = False
                    v_entries[i]["is_DurRangeAv_target"] = False
                    v_entries[i]["Pitch_other_valid"] = False
                    v_entries[i]["Intensity_other_valid"] = False

                else:
                    # 隣り合う母音(Pair)の長さの差（絶対値）
                    v_entries[i]["abs"] = abs(
                        v_entries[i + 1]["duration"] - v_entries[i]["duration"]
                    )

                    # 隣り合う母音(Pair)の長さの平均
                    v_entries[i]["avg"] = (
                        v_entries[i + 1]["duration"] + v_entries[i]["duration"]
                    ) / 2

                    # absをabgで割ったもの
                    v_entries[i]["abs_divided_by_avg"] = (
                        v_entries[i]["abs"] / v_entries[i]["avg"]
                    )

                    # 隣り合うMelの長さの差（絶対値）
                    try:
                        v_entries[i]["abs_Mel"] = abs(
                            v_entries[i + 1]["Mel"] - v_entries[i]["Mel"]
                        )
                    except TypeError:
                        pass

                    # 隣り合うdBの差(絶対値)
                    v_entries[i]["abs_dB"] = abs(
                        float(v_entries[i + 1]["dB"]) - float(v_entries[i]["dB"])
                    )

            # pr毎に最小値と最大値を保存する
            # pr内に有効なvが無い場合は対象としない
            df_vent = pd.DataFrame(v_entries)
            if len(df_vent):
                df_vent = df_vent[df_vent["is_DurRangeAv_target"] == True]

                # vが１つしかない場合はターゲットから外す
                if len(df_vent) > 1:
                    max_and_min_in_prs.append(
                        {
                            "max": df_vent["duration"].max(),
                            "min": df_vent["duration"].min(),
                        }
                    )

            df_vent = pd.DataFrame(v_entries)
            if len(df_vent):
                df_vent = df_vent[df_vent["Pitch_other_valid"] == True]
                df_vent = df_vent[df_vent["Mel"] != "--undefined--"]

                # vが１つしかない場合はターゲットから外す
                if len(df_vent) > 1:
                    max_and_min_in_PitRangeAv.append(
                        {"max": df_vent["Mel"].max(), "min": df_vent["Mel"].min()}
                    )

            df_vent = pd.DataFrame(v_entries)
            if len(df_vent):
                df_vent = df_vent[df_vent["Intensity_other_valid"] == True]

                # vが１つしかない場合はターゲットから外す
                if len(df_vent) > 1:
                    max_and_min_in_IntRangeAv.append(
                        {"max": df_vent["dB"].max(), "min": df_vent["dB"].min()}
                    )

            for item in v_entries:
                total_v_entries.append(item)

        # absにNaNがある行を削除
        df = pd.DataFrame(total_v_entries).dropna(subset=["abs"])

        # nVarDco 母音の長さの標準偏差を平均で割ったものに100をかけたもの。
        nVarDco = df["duration"].std() / df["duration"].mean() * 100
        self.nVarDco = nVarDco
        # nVarDcon上記3．で、nVarcoの計算に使われた”v”の数。
        nVarDcon = len(df)
        self.nVarDcon = nVarDcon
        # DurAllAv 全ての”v”（”vf”は除く）の長さの平均。
        DurAllAv = df["duration"].mean()
        self.DurAllAv = DurAllAv

        # Pitch #########################################################
        # nVarPco : 母音のピッチの標準偏差を平均で割ったものに100をかけたもの。
        # ”vf”, ”fp”, “rp”, “vl”, “jp”, “--undefined—"を除く
        dfmel = df[df["Mel"] != "--undefined--"]["Mel"]
        nVarPco = dfmel.std() / dfmel.mean() * 100
        self.nVarPco = nVarPco

        # nVarPcon : nVarPconの計算に使われたペアの数。
        nVarPcon = len(dfmel)
        self.nVarPcon = nVarPcon

        # PitAllAv : Melの平均
        PitAllAv = dfmel.mean()
        self.PitAllAv = PitAllAv
        #################################################################

        # Intensity #####################################################
        # nVarIco : 母音のIntensityの標準偏差を平均で割ったものに100をかけたもの。
        # ”vf”, ”fp”, “rp”, “vl”, “jp”を除く。
        nVarIco = df["dB"].std() / df["dB"].mean() * 100
        self.nVarIco = nVarIco
        nVarIcon = len(df)
        self.nVarIcon = nVarIcon

        IntAllAv = df["dB"].mean()
        self.IntAllAv = IntAllAv
        #################################################################
        # "duration_valid"がTrueのみのものを抽出する
        df = df[df["duration_valid"] == True]
        nPVI = df["abs_divided_by_avg"].sum() / len(df) * 100
        nPVIn = len(df)

        self.nPVI = nPVI
        self.nPVIn = nPVIn

        # DurRangeAv : Tier2の各”pr”の範囲内にあるTier3の”v”のピッチの最大値と最小値の差を出し、
        # それらを全てのprで平均する。”vf”, ”fp”, “rp”, “vl”, “jp”, “--undefined—"を除く。

        dif_list = [x["max"] - x["min"] for x in max_and_min_in_prs]
        DurRangeAv = sum(dif_list) / len(dif_list)

        self.DurRangeAv = DurRangeAv

        # Pitch #####################################################################################################
        # PitRangeAv : Tier2の各”pr”の範囲内にあるTier3の”v”のピッチの最大値と最小値の差を出し、それらを全てのprで平均する。
        # ”vf”, ”fp”, “rp”, “vl”, “jp”, “--undefined—"を除く。
        dif_list_PitRangeAv = [x["max"] - x["min"] for x in max_and_min_in_PitRangeAv]
        PitRangeAv = sum(dif_list_PitRangeAv) / len(dif_list_PitRangeAv)
        self.PitRangeAv = PitRangeAv

        # PPD　隣り合う母音の(Pair)の声の高さ(Pitch:Mel)の差の平均を出し、それをすべてのPairで平均
        # ppd = df["abs_Mel"].dropna().mean()
        df_PPD = df["abs_Mel"].dropna()
        ppd = df_PPD.mean()
        self.PPD = ppd
        PPDn = len(df_PPD)
        self.PPDn = PPDn
        # undefinedの数
        self.Undefined = undefined
        #############################################################################################################

        # Intensity #################################################################################################
        # ”vf”, ”fp”, “rp”, “vl”, “jp”,を除く。
        dif_list_IntRangeAv = [x["max"] - x["min"] for x in max_and_min_in_IntRangeAv]
        IntRangeAv = sum(dif_list_IntRangeAv) / len(dif_list_IntRangeAv)
        self.IntRangeAv = IntRangeAv

        df_pid = df["abs_dB"].dropna()
        pid = df_pid.mean()
        self.PID = pid
        pidn = len(df_pid)
        self.PIDn = pidn
        #############################################################################################################
        # print('duration完了')
        return True


def tg_L4rp_to_L3rp(textgrid_file_path: str):
    """L4のrpをL3のRPに変更する

    Args:
        textgrid_file_path (str): textgridファイルのパス
    """

    # TextGridを読み込む
    tg = textgrid.openTextgrid(textgrid_file_path, includeEmptyIntervals=True)

    # Tier4に"rp"というラベルのついたintervalを検索する
    rp_intervals = []
    for interval in tg._tierDict["Repair"].entries:
        if interval.label == "rp":
            rp_intervals.append(interval)

    # Tier3に"v"というラベルのついたintervalのラベルを変更する
    tier3 = tg._tierDict["DFauto (English)"]
    for interval in tier3.entries:
        for rp_interval in rp_intervals:
            if interval.start >= rp_interval.start and interval.end <= rp_interval.end:
                if interval.label == "v":
                    tier3.insertEntry(
                        (interval.start, interval.end, "rp"),
                        collisionMode="replace",
                        collisionReportingMode="silence",
                    )

    #  Tier2に"pr"というラベルの付いたintervalのラベルを変更する
    tier2 = tg._tierDict["Phrases"]
    for interval in tier2.entries:
        for rp_interval in rp_intervals:
            if interval.start >= rp_interval.start and interval.end <= rp_interval.end:
                if interval.label == "pr":
                    tier2.insertEntry(
                        (interval.start, interval.end, "rp"),
                        collisionMode="replace",
                        collisionReportingMode="silence",
                    )

    # Tire3で"fp"の部分は、Tier2で"fp"とするプログラム

    # Tier3に"fp"というラベルのついたintervalを検索する
    fp_intervals = []
    for interval in tg._tierDict["DFauto (English)"].entries:
        if interval.label == "fp":
            fp_intervals.append(interval)

    #  Tier2に"pr"というラベルの付いたintervalのラベルを変更する
    tier2 = tg._tierDict["Phrases"]
    for interval in tier2.entries:
        for fp_interval in fp_intervals:
            if interval.start >= fp_interval.start and interval.end <= fp_interval.end:
                if interval.label == "pr":
                    tier2.insertEntry(
                        (interval.start, interval.end, "fp"),
                        collisionMode="replace",
                        collisionReportingMode="silence",
                    )

    # 変更後のTextGridを上書き保存する
    tg.save(textgrid_file_path, format="short_textgrid", includeBlankSpaces=True)


from glob import glob

filelists = glob("./tgfiles/*.TextGrid")

dflist = []
for filename in filelists:
    tg_L4rp_to_L3rp(filename)

    tgd = tgdata(filename)

    df = pd.DataFrame([tgd.__dict__])
    dflist.append(df)


filename = "FluencyProsodyMasterData.xlsx"

if os.path.exists(filename):
    df_excelfile = pd.read_excel(filename)
    dflist.append(df_excelfile)


else:
    print(f"Error: {filename} not found.")

acum_df = pd.concat(dflist)

# カラム名[ID, RECN]で昇順に並び替えを行う
acum_df_sorted = acum_df.sort_values(by=["ID", "RECN"], ascending=True)

# 重複する行に新しいカラム"duplicate"を追加し、値を1に設定する
acum_df_sorted["duplicate"] = acum_df_sorted.duplicated(
    subset=["ID", "RECN"], keep=False
).astype(int)

# 並び順の整え
orderitem = [
    "filename",
    "ID",
    "RECN",
    "Date",
    "nsyll",
    "silenttot",
    "silenttot_ps",
    "silenttot_psb",
    "speakingtot",
    "asd",
    "nsounding",
    "npause",
    "npause_ps",
    "npause_psb",
    "nrFP",
    "tFP",
    "nrRP",
    "tRP",
    "durs",
    "SR",
    "SRP",
    "AR",
    "ARP",
    "MLoR",
    "PhonRat",
    "SPauseFreq",
    "SPauseDur",
    "FPauseFreq",
    "FPauseDur",
    "RpFreq",
    "RpDur",
    "SBPauseFreq",
    "SBPauseDur",
    "SWPauseFreq",
    "SWPauseDur",
    "nPVI",
    "nPVIn",
    "nVarDco",
    "nVarDcon",
    "DurAllAv",
    "DurRangeAv",
    "PPD",
    "PPDn",
    "nVarPco",
    "nVarPcon",
    "PitAllAv",
    "PitRangeAv",
    "Undefined",
    "PID",
    "PIDn",
    "nVarIco",
    "nVarIcon",
    "IntAllAv",
    "IntRangeAv",
    "duplicate",
]

acum_df_sorted = acum_df_sorted[orderitem]

acum_df_sorted.to_excel(filename, float_format="%.2f", index=False)
print("finished")
